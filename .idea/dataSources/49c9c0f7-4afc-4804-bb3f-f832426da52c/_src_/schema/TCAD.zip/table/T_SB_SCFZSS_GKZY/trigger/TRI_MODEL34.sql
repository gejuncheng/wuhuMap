create trigger TRI_MODEL34
	before insert
	on T_SB_SCFZSS_GKZY
	for each row
declare
  -- local variables here
begin
  select seq_id.nextval into :new.id from dual;
end tri_model34;
