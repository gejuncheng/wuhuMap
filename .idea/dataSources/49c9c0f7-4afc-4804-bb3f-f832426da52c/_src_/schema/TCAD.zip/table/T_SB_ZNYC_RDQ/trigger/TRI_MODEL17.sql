create trigger TRI_MODEL17
	before insert
	on T_SB_ZNYC_RDQ
	for each row
declare
  -- local variables here
begin
  select seq_id.nextval into :new.id from dual;
end tri_model17;
