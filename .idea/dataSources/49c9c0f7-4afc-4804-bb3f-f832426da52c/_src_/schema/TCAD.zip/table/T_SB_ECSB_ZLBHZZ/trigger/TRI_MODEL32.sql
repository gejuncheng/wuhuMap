create trigger TRI_MODEL32
	before insert
	on T_SB_ECSB_ZLBHZZ
	for each row
declare
  -- local variables here
begin
  select seq_id.nextval into :new.id from dual;
end tri_model32;
