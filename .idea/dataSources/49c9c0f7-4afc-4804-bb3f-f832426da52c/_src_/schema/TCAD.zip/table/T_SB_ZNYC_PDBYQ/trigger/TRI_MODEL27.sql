create trigger TRI_MODEL27
	before insert
	on T_SB_ZNYC_PDBYQ
	for each row
declare
  -- local variables here
begin
  select seq_id.nextval into :new.id from dual;
end tri_model27;
