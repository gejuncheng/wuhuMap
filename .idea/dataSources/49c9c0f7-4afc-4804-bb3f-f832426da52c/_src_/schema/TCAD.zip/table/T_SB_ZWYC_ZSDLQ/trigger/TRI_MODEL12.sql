create trigger TRI_MODEL12
	before insert
	on T_SB_ZWYC_ZSDLQ
	for each row
declare
  -- local variables here
begin
  select seq_id.nextval into :new.id from dual;
end tri_model12;
