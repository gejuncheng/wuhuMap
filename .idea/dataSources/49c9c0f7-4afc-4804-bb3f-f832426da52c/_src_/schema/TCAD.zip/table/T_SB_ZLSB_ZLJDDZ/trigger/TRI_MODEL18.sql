create trigger TRI_MODEL18
	before insert
	on T_SB_ZLSB_ZLJDDZ
	for each row
declare
  -- local variables here
begin
  select seq_id.nextval into :new.id from dual;
end tri_model18;
