create trigger TRI_MODEL21
	before insert
	on T_SB_ZNYC_MX
	for each row
declare
  -- local variables here
begin
  select seq_id.nextval into :new.id from dual;
end tri_model21;
